# SPRINTX111

Monorepo for tournament management (frontend + backend). This repo contains:

- `frontend/` — Next.js app (App Router) with registration, fixtures, schedule, leaderboard, and UI components
- `backend/` — Express TypeScript API with players, fixtures, schedule, matches logic and tests
- `docs/` — Design docs and diagrams

Quick start

1. Install dependencies in root, frontend and backend as needed.
2. Run backend: `cd backend && npm install && npm run dev`
3. Run frontend: `cd frontend && npm install && npm run dev`

See individual `package.json` files for scripts and dependencies.
