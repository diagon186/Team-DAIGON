(async ()=>{
  const base = 'http://localhost:5000'
  const post = async (path, body) => {
    const res = await fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    if (!res.ok) throw new Error(`POST ${path} failed: ${res.status}`)
    return res.json()
  }
  const get = async (path) => {
    const res = await fetch(base + path)
    if (!res.ok) throw new Error(`GET ${path} failed: ${res.status}`)
    return res.json()
  }

  try {
    const names = ['Alice','Bob','Carol','Dave']
    for (const n of names) {
      const p = await post('/players', { name: n })
      console.log('created player', p)
    }

    const fixtures = await post('/fixtures', {})
    console.log('fixtures created', fixtures)

    const scheduleRes = await post('/schedule', {})
    console.log('schedule created', scheduleRes)

    const schedules = await get('/schedule')
    console.log('schedules:', schedules)

    const matchId = schedules[0].matchId
    console.log('chosen matchId:', matchId)

    const codeRes = await post('/matches', { matchId, ttlMin: 5 })
    console.log('code created', codeRes)

    const code = codeRes.code
    const fixturesAll = await get('/fixtures')
    const match = fixturesAll.find(f => f.id === matchId)
    const playerA = match.playerAId
    console.log('playerA:', playerA)

    const put = await fetch(`${base}/matches/${code}`, { method: 'PUT', headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ winnerId: playerA, score: '6-0,6-0' }) })
    console.log('submit result status', put.status)
    const putJson = await put.json()
    console.log('put response', putJson)

    const lb = await get('/leaderboard')
    console.log('leaderboard', lb)

  } catch (e) {
    console.error('E2E error', e)
    process.exit(1)
  }
})();
