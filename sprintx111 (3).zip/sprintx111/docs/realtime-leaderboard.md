# Realtime & Leaderboard

Server
- Socket.IO server is initialized in `backend/src/socket.ts` and attached in `backend/src/index.ts`.
- Routes emit events when fixtures, schedules, or match results change. See `routes/fixtures.ts`, `routes/schedule.ts`, and `routes/matches.ts`.

Client
- Frontend connects using `socket.io-client` and listens to events to refresh leaderboard and schedules.
