# Match Code & Result Flow

Overview
- Umpires request a short, time-limited code for a scheduled match via `POST /matches`.
- The code is valid for the TTL (default 30 minutes). Umpires submit results via `PUT /matches/:code`.
- Codes can be revoked via `DELETE /matches/:code`.

Server behavior
- Codes are stored on the fixture record in the JSON DB (`backend/data/db.json`).
- Submitting a result marks the fixture `status = 'completed'` and records `result` payload.
- When an entire round's matches are completed, the server auto-advances winners into the next round and persists new fixtures.

Frontend
- We provide a simple Umpire UI at `/umpire` to request a code, submit a result, or revoke a code.

Realtime
- The server emits socket events: `fixtures:updated`, `schedule:updated`, `match:result`, `match:revoked`, and `fixtures:advanced`.
# Match Code Flow

Sequence:

1. `POST /matches` -> server generates short code and expiry timestamp
2. Umpire enters code in UI -> `POST /matches/validate` or `PUT /matches/:code`
3. Server validates code and expiry; if valid, returns match details and allows score submission

```mermaid
sequenceDiagram
  participant U as Umpire
  participant F as Frontend
  participant B as Backend
  U->>F: Enter code
  F->>B: Validate code (PUT /matches/:code)
  B-->>F: Valid / Expired
  F->>B: Submit result
```
