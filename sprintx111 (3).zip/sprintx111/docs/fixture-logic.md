# Fixture Logic

## Overview
Greedy knockout generator that shuffles players, assigns byes when odd, and swaps to avoid early same-club matches where possible.

## Pseudocode

1. Shuffle players
2. If odd, give highest-seeded player a bye
3. Pair sequentially
4. Detect same-club pairings and attempt local swaps to reduce occurrence

## Tests
- Odd player bye
- Avoidance >90% (heuristic)
- Match count n-1 for knockout

```mermaid
graph TD
  A[Start] --> B[Shuffle Players]
  B --> C{Odd?}
  C -- Yes --> D[Give Bye]
  C -- No --> E[Pair Sequentially]
  E --> F[Swap to avoid club conflicts]
  F --> G[Output Fixtures]
```
