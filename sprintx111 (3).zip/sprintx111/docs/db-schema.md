# DB Schema

Tables:

- players
  - id (pk)
  - name
  - club_id
  - seed
  - created_at

- matches
  - id (pk)
  - player_a_id
  - player_b_id
  - scheduled_at
  - code
  - expires_at
  - result

- schedules
  - id (pk)
  - match_id
  - court
  - start_time
  - end_time

Rules:
- Unique constraint on (club, player_name) to avoid duplicates
- Match code expiry enforced server-side
