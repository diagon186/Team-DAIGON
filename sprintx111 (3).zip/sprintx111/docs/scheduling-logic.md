# Scheduling Logic

## Queue Flow
- Incoming assignments are enqueued with priority (e.g., match importance, court constraints).
- A buffer maintains a small number of upcoming slots (+10 minutes buffer) to allow swaps without overlap.

## Example
- Assignment submitted: 9:10 → preferred slot 9:20
- Scheduler places in queue and assigns next available slot while ensuring no overlap and respecting idle <5min rules.

## Notes
- Use a min-heap by start-time for efficient next-slot selection.
- Implement withdraw ripple: removing an assignment shifts later assignments but tries to keep changes minimal.
