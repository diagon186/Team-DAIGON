import { scheduleMatches } from '../src/models/Scheduler'

test('schedules assign matches across courts and enforce buffer', ()=>{
  const matches = [
    { id: 'm1', playerAId: 'p1', playerBId: 'p2', round: 1 },
    { id: 'm2', playerAId: 'p3', playerBId: 'p4', round: 1 },
    { id: 'm3', playerAId: 'p5', playerBId: 'p6', round: 1 },
    { id: 'm4', playerAId: 'p7', playerBId: 'p8', round: 1 }
  ]
  const start = Date.now()
  const scheduled = scheduleMatches(matches, { courts: ['C1','C2'], matchDurationMin: 10, bufferMin: 10, startAt: start })
  // ensure each match assigned
  expect(scheduled.length).toBe(matches.length)
  // no overlapping on same court and buffer enforced
  const byCourt: Record<string, any[]> = {}
  for (const s of scheduled) {
    byCourt[s.court] = byCourt[s.court] || []
    byCourt[s.court].push(s)
  }
  for (const court of Object.keys(byCourt)){
    const arr = byCourt[court].sort((a,b)=>a.start-b.start)
    for (let i=1;i<arr.length;i++){
      expect(arr[i].start).toBeGreaterThanOrEqual(arr[i-1].end + (10*60*1000) - 1000) // allow 1s leeway
    }
  }
})

test('no overlapping matches for same player across courts', ()=>{
  const matches = [
    { id: 'm1', playerAId: 'p1', playerBId: 'p2', round: 1 },
    { id: 'm2', playerAId: 'p1', playerBId: 'p3', round: 1 },
    { id: 'm3', playerAId: 'p4', playerBId: 'p5', round: 1 }
  ]
  const start = Date.now()
  const scheduled = scheduleMatches(matches, { courts: ['C1','C2'], matchDurationMin: 10, bufferMin: 10, startAt: start })
  // find scheduled matches for p1
  const p1Matches = scheduled.filter(s => s.matchId === 'm1' || s.matchId === 'm2')
  expect(p1Matches.length).toBe(2)
  // ensure they don't overlap
  const a = p1Matches[0]
  const b = p1Matches[1]
  const before = a.start < b.start ? a : b
  const after = a.start < b.start ? b : a
  expect(after.start).toBeGreaterThanOrEqual(before.end + (10*60*1000) - 1000)
})
