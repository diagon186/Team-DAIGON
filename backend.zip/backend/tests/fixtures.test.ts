import { generateKnockout } from '../src/models/FixtureEngine'

test('generate fixtures with odd bye', ()=>{
  const players = [
    { id: 'p1', name: 'A', clubId: 'c1' },
    { id: 'p2', name: 'B', clubId: 'c2' },
    { id: 'p3', name: 'C', clubId: 'c3' }
  ]
  const out = generateKnockout(players)
  expect(out.byes.length).toBe(1)
  expect(out.matches.length).toBeGreaterThan(0)
})

test('match count equals floor(n/2) for first round and n-1 total for knockout progression (sanity)', ()=>{
  const players = [
    { id: 'a' }, { id: 'b' }, { id: 'c' }, { id: 'd' }
  ]
  const out = generateKnockout(players)
  expect(out.matches.length).toBe(2)
})

test('same-club avoidance reduces early conflicts (best-effort)', ()=>{
  const players = [
    { id: 'p1', clubId: 'x' },
    { id: 'p2', clubId: 'x' },
    { id: 'p3', clubId: 'y' },
    { id: 'p4', clubId: 'z' }
  ]
  const out = generateKnockout(players, { avoidSameClub: true })
  // count same-club matches
  const sameClub = out.matches.filter(m => m.playerA.clubId && m.playerB && m.playerB.clubId && m.playerA.clubId === m.playerB.clubId).length
  expect(sameClub).toBe(0)
})
