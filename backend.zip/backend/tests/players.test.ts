import request from 'supertest'
import express from 'express'
import playersRouter from '../src/routes/players'
import fs from 'fs'
import path from 'path'

// ensure a clean DB for tests
const dbFile = path.resolve(__dirname, '../../data/db.json')
if (fs.existsSync(dbFile)) {
  try { fs.unlinkSync(dbFile) } catch (e) {}
}

const app = express()
app.use(express.json())
app.use('/players', playersRouter)

test('GET players returns list', async ()=>{
  const res = await request(app).get('/players')
  expect(res.status).toBe(200)
  expect(Array.isArray(res.body)).toBe(true)
})

test('POST without name returns 400', async ()=>{
  const res = await request(app).post('/players').send({})
  expect(res.status).toBe(400)
})

test('POST duplicate returns 409', async ()=>{
  // create once
  const res1 = await request(app).post('/players').send({ name: 'dup' })
  expect(res1.status).toBe(201)
  // create duplicate
  const res2 = await request(app).post('/players').send({ name: 'dup' })
  expect(res2.status).toBe(409)
})
