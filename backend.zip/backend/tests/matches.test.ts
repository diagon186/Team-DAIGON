import request from 'supertest'
import express from 'express'
import matchesRouter from '../src/routes/matches'
import fixturesRouter from '../src/routes/fixtures'
import db from '../src/db'

const app = express()
app.use(express.json())
app.use('/fixtures', fixturesRouter)
app.use('/matches', matchesRouter)

test('generate code for fixture and submit result', async ()=>{
  // create fixtures by posting to /fixtures (this will generate fixtures from empty DB players -> will return 404)
  // Instead, create a player and fixture via direct POST to players and fixtures
  // For test simplicity, call POST /fixtures which reads players; ensure there is at least one player by mocking
  // But to keep test isolated, we'll directly simulate a stored fixture by calling POST /fixtures with players body
  const players = [{ id: 'p1', name: 'A' }, { id: 'p2', name: 'B' }]
  const res = await request(app).post('/fixtures').send({ players })
  expect(res.status).toBe(201)
  const match = res.body.matches[0]
  expect(match).toBeDefined()

  // generate code for this match
  const codeRes = await request(app).post('/matches').send({ matchId: match.id, ttlMin: 1 })
  expect(codeRes.status).toBe(201)
  const code = codeRes.body.code
  expect(code).toBeDefined()

  // submit result
  const put = await request(app).put(`/matches/${code}`).send({ winnerId: 'p1', score: '6-3,6-4' })
  expect(put.status).toBe(200)
  expect(put.body.accepted).toBe(true)
})

test('invalid code rejected', async ()=>{
  const app2 = express(); app2.use(express.json()); app2.use('/matches', matchesRouter)
  const res = await request(app2).put('/matches/invalidcode').send({})
  expect(res.status).toBe(404)
})

test('expired code is rejected and revoke works', async ()=>{
  const app3 = express(); app3.use(express.json()); app3.use('/fixtures', fixturesRouter); app3.use('/matches', matchesRouter)
  const players = [{ id: 'p10', name: 'X' }, { id: 'p11', name: 'Y' }]
  const res = await request(app3).post('/fixtures').send({ players })
  expect(res.status).toBe(201)
  const match = res.body.matches[0]

  // create code with 0 minute TTL (expires immediately)
  const codeRes = await request(app3).post('/matches').send({ matchId: match.id, ttlMin: 0 })
  expect(codeRes.status).toBe(201)
  const code = codeRes.body.code
  expect(code).toBeDefined()

  // force expiry by setting codeExpiresAt in the past
  db.setMatchCode(match.id, code, Date.now() - 1000)
  const put = await request(app3).put(`/matches/${code}`).send({ winnerId: 'p10' })
  expect(put.status).toBe(410)

  // revoke (should still find match by code even if expired)
  const del = await request(app3).delete(`/matches/${code}`)
  expect(del.status).toBe(200)
  expect(del.body.revoked).toBe(true)
})
