import request from 'supertest'
import express from 'express'
import fixturesRouter from '../src/routes/fixtures'
import matchesRouter from '../src/routes/matches'

const app = express()
app.use(express.json())
app.use('/fixtures', fixturesRouter)
app.use('/matches', matchesRouter)

test('auto-advance creates next round when all matches complete', async ()=>{
  // create 4 players => 2 matches in round 1
  const players = [
    { id: 'pa', name: 'A' }, { id: 'pb', name: 'B' }, { id: 'pc', name: 'C' }, { id: 'pd', name: 'D' }
  ]
  const res = await request(app).post('/fixtures').send({ players })
  expect(res.status).toBe(201)
  const matches = res.body.matches
  expect(matches.length).toBe(2)

  // create code and submit results for both matches
  for (const m of matches) {
    const codeRes = await request(app).post('/matches').send({ matchId: m.id, ttlMin: 10 })
    expect(codeRes.status).toBe(201)
    const code = codeRes.body.code
    // pick playerA as winner
    const put = await request(app).put(`/matches/${code}`).send({ winnerId: m.playerA.id })
    expect(put.status).toBe(200)
  }

  // after both results submitted, auto-advance should create a round 2 match
  const fixturesRes = await request(app).get('/fixtures')
  const all = fixturesRes.body
  const round2 = all.filter((f:any)=>f.round === 2)
  expect(round2.length).toBeGreaterThan(0)
})
