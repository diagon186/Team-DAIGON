import { Router, Request, Response } from 'express'
import db from '../db'
import { v4 as uuidv4 } from 'uuid'

const router = Router()

router.get('/', (_req: Request, res: Response) => {
  const clubs = db.getClubs()
  res.json(clubs)
})

router.post('/', (req: Request, res: Response) => {
  const { name } = req.body as { name?: string }
  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    return res.status(400).json({ error: 'Name required' })
  }

  // unique name check
  const existing = db.getClubs().find(c => c.name.toLowerCase() === name.trim().toLowerCase())
  if (existing) return res.status(409).json({ error: 'Duplicate club' })

  const club = { id: uuidv4(), name: name.trim() }
  db.addClub(club)
  res.status(201).json(club)
})

export default router
