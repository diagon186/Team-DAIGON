import { Router, Request, Response } from 'express'
import db from '../db'
import { v4 as uuidv4 } from 'uuid'

const router = Router()

router.get('/', (_req: Request, res: Response) => {
  const rows = db.getPlayers()
  res.json(rows)
})

router.post('/', (req: Request, res: Response) => {
  const { name, clubId } = req.body as { name?: string; clubId?: string }
  if (!name || typeof name !== 'string' || name.trim().length === 0) {
    return res.status(400).json({ error: 'Name required' })
  }

  // duplicate name check
  const dup = db.findPlayerByName(name.trim())
  if (dup) return res.status(409).json({ error: 'Duplicate' })

  const id = uuidv4()
  const now = Date.now()
  const player = { id, name: name.trim(), clubId: clubId || null, createdAt: now }
  db.addPlayer(player)

  res.status(201).json(player)
})

router.put('/:id', (req: Request, res: Response) => {
  const { id } = req.params
  const { name, clubId } = req.body as { name?: string; clubId?: string }
  const updated = db.updatePlayer(id, { name, clubId })
  if (!updated) return res.status(404).json({ error: 'Not found' })
  res.json({ updated: true })
})

export default router
