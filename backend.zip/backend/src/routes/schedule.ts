import { Router, Request, Response } from 'express'
import { scheduleMatches } from '../models/Scheduler'
import db from '../db'

const router = Router()

router.post('/', (req: Request, res: Response) => {
  // Accept matches (fixture match objects) in body or load from stored fixtures
  const matchesInput = (req.body as any).matches
  let matches = [] as any[]
  if (Array.isArray(matchesInput) && matchesInput.length>0) {
    matches = matchesInput
  } else {
    // load persisted fixtures and map to expected FixtureMatch shape
    const fixtures = db.getFixtures()
    matches = fixtures.map((f:any) => ({ id: f.id, playerAId: f.playerAId, playerBId: f.playerBId, round: f.round }))
  }

  const courts = (req.body && (req.body as any).courts) || ['Court 1', 'Court 2', 'Court 3']
  const durationMin = (req.body && (req.body as any).matchDurationMin) || 10
  const bufferMin = (req.body && (req.body as any).bufferMin) || 10
  const startAt = (req.body && (req.body as any).startAt) || Date.now()

  const scheduled = scheduleMatches(matches, { courts, matchDurationMin: durationMin, bufferMin, startAt })

  // persist schedules
  db.addSchedules(scheduled)

  // emit schedule updated
  try {
    const { getIo } = require('../socket')
    const io = getIo()
    io.emit('schedule:updated', { scheduled })
  } catch (e) {
    // ignore if socket not ready
  }

  res.status(201).json({ scheduled })
})

router.get('/', (_req: Request, res: Response) => {
  const schedules = db.getSchedules()
  res.json(schedules)
})

// Reschedule endpoint: supports withdrawing a match or applying a global delay and re-running the scheduler
router.post('/reschedule', (req: Request, res: Response) => {
  const body = req.body as any
  const action: 'withdraw' | 'delay' = body.action
  const matchId: string | undefined = body.matchId
  const courts = body.courts || ['Court 1', 'Court 2', 'Court 3']
  const durationMin = body.matchDurationMin || 10
  const bufferMin = body.bufferMin || 10
  // for delay: optionally accept delayMin or startAt
  const delayMin = body.delayMin as number | undefined
  const startAt = body.startAt || (delayMin ? Date.now() + delayMin * 60 * 1000 : Date.now())

  if (action === 'withdraw') {
    if (!matchId) return res.status(400).json({ error: 'matchId required for withdraw' })
    // mark fixture withdrawn and remove any schedules for it
    db.setFixtureStatus(matchId, 'withdrawn')
    db.removeSchedulesForMatch(matchId)
  }

  // For both withdraw and delay we will clear existing schedules and rebuild schedules for active fixtures
  db.clearSchedules()

  const fixtures = db.getActiveFixtures()
  // map to expected input for scheduleMatches
  const matches = fixtures.map((f:any) => ({ id: f.id, playerAId: f.playerAId, playerBId: f.playerBId, round: f.round }))

  const scheduled = scheduleMatches(matches, { courts, matchDurationMin: durationMin, bufferMin, startAt })
  db.addSchedules(scheduled)

  res.status(201).json({ scheduled })
})

export default router
