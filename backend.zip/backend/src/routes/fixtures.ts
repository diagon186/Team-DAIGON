import { Router, Request, Response } from 'express'
import { generateKnockout } from '../models/FixtureEngine'
import db from '../db'

const router = Router()

router.post('/', (req: Request, res: Response) => {
  // Accept optional players list in body; otherwise use all registered players
  const playersInput = (req.body as any).players
  let players = [] as any[]
  if (Array.isArray(playersInput) && playersInput.length>0) {
    players = playersInput
  } else {
    players = db.getPlayers()
  }

  // transform to PlayerForFixture minimal shape
  const pf = players.map(p=> ({ id: p.id, name: p.name, clubId: p.clubId }))
  const { matches, byes } = generateKnockout(pf, { avoidSameClub: true })

  // persist matches
  db.addFixtures(matches as any)

  // emit realtime event for new fixtures
  try {
    const { getIo } = require('../socket')
    const io = getIo()
    io.emit('fixtures:updated', { matches, byes })
  } catch (e) {
    // socket may not be initialized in tests/environment
  }

  res.status(201).json({ matches, byes })
})

router.get('/', (_req: Request, res: Response) => {
  const fixtures = db.getFixtures()
  res.json(fixtures)
})

export default router
