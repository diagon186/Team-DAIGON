import { Router, Request, Response } from 'express'
import db from '../db'

const router = Router()

// Simple leaderboard: count wins per player from fixtures results
router.get('/', (_req: Request, res: Response) => {
  const fixtures = db.getFixtures()
  const counts: Record<string, { playerId: string; wins: number }> = {}
  for (const f of fixtures) {
    if (f.result && f.result.winnerId) {
      const w = f.result.winnerId
      counts[w] = counts[w] || { playerId: w, wins: 0 }
      counts[w].wins++
    }
  }
  const arr = Object.values(counts).sort((a,b)=>b.wins - a.wins)
  res.json(arr)
})

export default router
