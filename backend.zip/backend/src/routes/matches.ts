import { Router, Request, Response } from 'express'
import shortid from 'shortid'
import db from '../db'

const router = Router()

// Generate a match code for a given match id (or create code for next unassigned match)
router.post('/', (req: Request, res: Response) => {
  const { matchId, ttlMin } = req.body as { matchId?: string; ttlMin?: number }
  const ttl = (ttlMin && typeof ttlMin === 'number') ? ttlMin : 30

  let target: any = null
  if (matchId) {
    const fixtures = db.getFixtures()
    target = fixtures.find((f:any)=>f.id===matchId)
    if (!target) return res.status(404).json({ error: 'match not found' })
  } else {
    // find first scheduled match without code
    const fixtures = db.getFixtures()
    target = fixtures.find((f:any)=>!f.code)
    if (!target) return res.status(404).json({ error: 'no eligible match' })
  }

  const code = shortid.generate()
  const expiresAt = Date.now() + ttl * 60 * 1000
  const updated = db.setMatchCode(target.id, code, expiresAt)
  if (!updated) return res.status(500).json({ error: 'unable to set code' })
  res.status(201).json({ code, expiresAt })
})

// Validate code and submit result
router.put('/:code', (req: Request, res: Response) => {
  const { code } = req.params
  const payload = req.body
  const match = db.getMatchByCode(code)
  if (!match) return res.status(404).json({ error: 'invalid code' })
  if (match.codeExpiresAt && Date.now() > match.codeExpiresAt) return res.status(410).json({ error: 'code expired' })

  // accept result and expire code
  const updated = db.submitResultByCode(code, payload)
  if (!updated) return res.status(500).json({ error: 'unable to submit result' })

  // emit result update
  try {
    const { getIo } = require('../socket')
    const io = getIo()
    io.emit('match:result', { match: updated })
  } catch (e) {}

  // attempt to auto-advance winners to next round
  try {
    const { advanceIfRoundComplete } = require('../models/AutoAdvance')
    advanceIfRoundComplete(updated.id)
  } catch (e) {}

  res.json({ accepted: true, match: updated })
})

// Revoke/expire a code without submitting a result (e.g., wrong code issued)
router.delete('/:code', (req: Request, res: Response) => {
  const { code } = req.params
  const match = db.getMatchByCode(code)
  if (!match) return res.status(404).json({ error: 'invalid code' })
  const revoked = db.revokeCode(code)
  if (!revoked) return res.status(500).json({ error: 'unable to revoke code' })
  try {
    const { getIo } = require('../socket')
    const io = getIo()
    io.emit('match:revoked', { match: revoked })
  } catch (e) {}
  res.json({ revoked: true, match: revoked })
})

export default router
