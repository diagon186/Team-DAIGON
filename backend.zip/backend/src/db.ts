import fs from 'fs'
import path from 'path'

type Player = { id: string; name: string; clubId?: string | null; createdAt: number }
type Club = { id: string; name: string }
type StoredMatch = { id: string; playerAId: string; playerBId?: string | null; round: number; createdAt: number; code?: string | null; codeExpiresAt?: number | null; result?: any | null; status?: 'scheduled' | 'completed' }

const dataDir = path.resolve(__dirname, '../../data')
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true })

const file = path.resolve(dataDir, 'db.json')

function readData() {
  if (!fs.existsSync(file)) {
    const initial = { players: [] as Player[], clubs: [] as Club[] }
    fs.writeFileSync(file, JSON.stringify(initial, null, 2))
    return initial
  }
  const raw = fs.readFileSync(file, 'utf8')
  try {
    return JSON.parse(raw) as { players: Player[]; clubs: Club[] }
  } catch (e) {
    const initial = { players: [] as Player[], clubs: [] as Club[] }
    fs.writeFileSync(file, JSON.stringify(initial, null, 2))
    return initial
  }
}

function writeData(data: { players: Player[]; clubs: Club[] }) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2))
}

const api = {
  getPlayers: () => {
    const db = readData()
    return db.players
  },
  findPlayerByName: (name: string) => {
    const db = readData()
    return db.players.find(p => p.name.toLowerCase() === name.toLowerCase())
  },
  addPlayer: (player: Player) => {
    const db = readData()
    db.players.push(player)
    writeData(db)
    return player
  },
  updatePlayer: (id: string, patch: Partial<Player>) => {
    const db = readData()
    const p = db.players.find(x => x.id === id)
    if (!p) return null
    Object.assign(p, patch)
    writeData(db)
    return p
  },
  getClubs: () => {
    const db = readData()
    return db.clubs
  },
  addClub: (club: Club) => {
    const db = readData()
    db.clubs.push(club)
    writeData(db)
    return club
  }
  ,
  addFixtures: (matches: { id: string; playerA: Player; playerB?: Player | null; round: number }[]) => {
    const dbData = readData() as any
    const stored: StoredMatch[] = matches.map(m => ({ id: m.id, playerAId: m.playerA.id, playerBId: m.playerB?.id ?? null, round: m.round, createdAt: Date.now(), code: null, codeExpiresAt: null, result: null, status: 'scheduled' }))
    // store on a top-level fixtures array
    if (!dbData.fixtures) dbData.fixtures = []
    dbData.fixtures.push(...stored)
    writeData(dbData)
    return stored
  },
  getFixtures: () => {
    const dbd = readData() as any
    return dbd.fixtures || []
  }
  ,
  // match code & result helpers
  setMatchCode: (matchId: string, code: string, expiresAt: number) => {
    const dbd = readData() as any
    if (!dbd.fixtures) dbd.fixtures = []
    const m = dbd.fixtures.find((x:any)=>x.id===matchId)
    if (!m) return null
    m.code = code
    m.codeExpiresAt = expiresAt
    writeData(dbd)
    return m
  },
  getMatchByCode: (code: string) => {
    const dbd = readData() as any
    if (!dbd.fixtures) return null
    return dbd.fixtures.find((x:any)=>x.code===code) || null
  },
  submitResultByCode: (code: string, result: any) => {
    const dbd = readData() as any
    if (!dbd.fixtures) return null
    const m = dbd.fixtures.find((x:any)=>x.code===code)
    if (!m) return null
    m.result = result
    m.status = 'completed'
    // expire the code
    m.codeExpiresAt = Date.now()
    writeData(dbd)
    return m
  }
  ,
  revokeCode: (code: string) => {
    const dbd = readData() as any
    if (!dbd.fixtures) return null
    const m = dbd.fixtures.find((x:any)=>x.code===code)
    if (!m) return null
    m.code = null
    m.codeExpiresAt = Date.now()
    writeData(dbd)
    return m
  }
  ,
  addSchedules: (schedules: { id: string; matchId: string; court: string; start: number; end: number }[]) => {
    const dbd = readData() as any
    if (!dbd.schedules) dbd.schedules = []
    dbd.schedules.push(...schedules)
    writeData(dbd)
    return schedules
  },
  getSchedules: () => {
    const dbd = readData() as any
    return dbd.schedules || []
  }
  ,
  // schedule / fixture management helpers
  clearSchedules: () => {
    const dbd = readData() as any
    dbd.schedules = []
    writeData(dbd)
    return []
  },
  removeSchedulesForMatch: (matchId: string) => {
    const dbd = readData() as any
    if (!dbd.schedules) return []
    dbd.schedules = dbd.schedules.filter((s:any)=>s.matchId !== matchId)
    writeData(dbd)
    return dbd.schedules
  },
  setFixtureStatus: (matchId: string, status: string) => {
    const dbd = readData() as any
    if (!dbd.fixtures) return null
    const m = dbd.fixtures.find((x:any)=>x.id===matchId)
    if (!m) return null
    m.status = status
    writeData(dbd)
    return m
  },
  getActiveFixtures: () => {
    const dbd = readData() as any
    if (!dbd.fixtures) return []
    // return fixtures not withdrawn
    return dbd.fixtures.filter((x:any)=>x.status !== 'withdrawn')
  }
  ,
  // add fixtures when you already have player ids (used by auto-advance)
  addRawFixtures: (matches: { id: string; playerAId: string; playerBId?: string | null; round: number }[]) => {
    const dbd = readData() as any
    if (!dbd.fixtures) dbd.fixtures = []
    const stored: StoredMatch[] = matches.map(m => ({ id: m.id, playerAId: m.playerAId, playerBId: m.playerBId ?? null, round: m.round, createdAt: Date.now(), code: null, codeExpiresAt: null, result: null, status: 'scheduled' }))
    dbd.fixtures.push(...stored)
    writeData(dbd)
    return stored
  }
}

export default api
