import { Request, Response, NextFunction } from 'express'

export function validateSchema(schema: any){
  return (req: Request, res: Response, next: NextFunction) => {
    // placeholder wrapper
    try{
      next()
    }catch(err){
      res.status(400).json({ error: 'validation failed' })
    }
  }
}
