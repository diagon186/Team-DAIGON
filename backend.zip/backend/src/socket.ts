import http from 'http'
import { Server as IOServer } from 'socket.io'

let io: IOServer | null = null

export function initSocket(server: http.Server) {
  if (io) return io
  io = new IOServer(server, { cors: { origin: '*' } })
  io.on('connection', socket => {
    console.log('socket connected', socket.id)
    socket.on('disconnect', () => console.log('socket disconnected', socket.id))
  })
  return io
}

export function getIo() {
  if (!io) throw new Error('Socket.IO not initialized')
  return io
}
