import express, { Request, Response } from 'express'
import cors from 'cors'
import http from 'http'
import playersRouter from './routes/players'
import fixturesRouter from './routes/fixtures'
import scheduleRouter from './routes/schedule'
import matchesRouter from './routes/matches'
import clubsRouter from './routes/clubs'
import { initSocket } from './socket'

const app = express()
app.use(cors())
app.use(express.json())

app.use('/players', playersRouter)
app.use('/fixtures', fixturesRouter)
app.use('/schedule', scheduleRouter)
app.use('/matches', matchesRouter)
app.use('/clubs', clubsRouter)
// load leaderboard route dynamically to avoid hard crash if module missing
try {
	// require here so any runtime errors in the route file don't bring down the app at import time
	// prefer ES default export if present
	// eslint-disable-next-line @typescript-eslint/no-var-requires
	const lb = require('./routes/leaderboard')
	const leaderboardRouter = lb && lb.default ? lb.default : lb
	app.use('/leaderboard', leaderboardRouter)
} catch (err:any) {
	console.warn('Could not load leaderboard route:', err && err.message ? err.message : err)
}

app.get('/health', (_req: Request, res: Response) => res.json({ status: 'ok' }))

const port = process.env.PORT || 5000
const server = http.createServer(app)

// initialize socket.io safely (don't crash the server if it fails)
let ioInstance: any = null
try {
	ioInstance = initSocket(server)
	console.log('Socket.IO initialized')
} catch (err) {
	console.warn('Socket.IO failed to initialize:', err)
}

server.listen(port, () => console.log(`Backend listening on ${port}`))

// Graceful shutdown
const shutdown = () => {
	console.log('Shutting down server...')
	try {
		server.close(() => {
			console.log('HTTP server closed')
			if (ioInstance && ioInstance.close) ioInstance.close()
			process.exit(0)
		})
	} catch (e) {
		console.error('Error during shutdown', e)
		process.exit(1)
	}
	// force exit after 5s
	setTimeout(() => process.exit(1), 5000)
}

process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)

// export for integration tests
export { app, server }
