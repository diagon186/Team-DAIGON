export class ScheduleModel {
  static assign(tasks:any[]){
    // priority heap placeholder: just return tasks with assigned timestamps
    return tasks.map((t,i)=>({ ...t, scheduledAt: Date.now() + i*60000 }))
  }
}
