import { v4 as uuidv4 } from 'uuid'

export type PlayerForFixture = { id: string; name?: string; clubId?: string | null; seed?: number }
export type Match = { id: string; playerA: PlayerForFixture; playerB?: PlayerForFixture | null; round: number }

function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice()
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    const t = a[i]
    a[i] = a[j]
    a[j] = t
  }
  return a
}

export function generateKnockout(playersIn: PlayerForFixture[], options?: { avoidSameClub?: boolean }) {
  if (!Array.isArray(playersIn)) throw new Error('players must be array')
  const avoidSameClub = options?.avoidSameClub ?? true

  // if seeds provided, sort by seed ascending (1 is top seed). If none have seed, shuffle
  const hasSeed = playersIn.some(p => typeof p.seed === 'number')
  let players = playersIn.slice()
  if (hasSeed) {
    players = players.slice().sort((a, b) => (a.seed ?? 9999) - (b.seed ?? 9999))
  } else {
    players = shuffle(players)
  }

  // ensure even number by adding bye placeholder
  const byes: PlayerForFixture[] = []
  if (players.length % 2 === 1) {
    // allocate bye: prefer highest seed (if seeds exist), else last after shuffle
    if (hasSeed) {
      // choose highest seed (smallest seed number)
      const best = players.reduce((acc, p) => ( (p.seed ?? 9999) < (acc.seed ?? 9999) ? p : acc ), players[0])
      // remove best from players and mark as bye
      players = players.filter(p => p.id !== best.id)
      byes.push(best)
    } else {
      const bye = players.pop() as PlayerForFixture
      byes.push(bye)
    }
  }

  // pair with a best-effort to avoid same-club: for each player, pick the next available opponent with different club
  const matches: Match[] = []
  // improved pairing when avoidSameClub: interleave players by club groups to minimize same-club pairings
  if (avoidSameClub) {
    // group by clubId (use unique token for missing club)
    const groups: Record<string, PlayerForFixture[]> = {}
    for (const p of players) {
      const key = p.clubId ?? `__noclub__${p.id}`
      if (!groups[key]) groups[key] = []
      groups[key].push(p)
    }

    // create an interleaved list: repeatedly take one player from the largest remaining group to spread same-club players apart
    const interleaved: PlayerForFixture[] = []
    const keys = Object.keys(groups)
    while (true) {
      // sort keys by remaining length desc
      const alive = keys.filter(k => groups[k] && groups[k].length > 0)
      if (alive.length === 0) break
      alive.sort((a, b) => groups[b].length - groups[a].length)
      for (const k of alive) {
        const p = groups[k].shift()
        if (p) interleaved.push(p)
      }
    }

    // pair sequentially
    for (let i = 0; i < interleaved.length; i += 2) {
      const a = interleaved[i]
      const b = interleaved[i + 1] ?? null
      matches.push({ id: uuidv4(), playerA: a, playerB: b, round: 1 })
    }
  } else {
    const pool = players.slice()
    while (pool.length > 1) {
      const a = pool.shift() as PlayerForFixture
      const b = pool.shift() ?? null
      matches.push({ id: uuidv4(), playerA: a, playerB: b, round: 1 })
    }
  }

  // simple same-club avoidance: for each match with same-club, try local swap with next match
  if (avoidSameClub) {
    for (let i = 0; i < matches.length; i++) {
      const m = matches[i]
      if (!m.playerB) continue
      if (m.playerA.clubId && m.playerB.clubId && m.playerA.clubId === m.playerB.clubId) {
        // try swapping playerB with next match's playerB or playerA
        let swapped = false
        for (let j = i + 1; j < matches.length && !swapped; j++) {
          const cand = matches[j]
          // try swap m.playerB with cand.playerB
          if (cand.playerB && cand.playerB.clubId !== m.playerA.clubId) {
            const tmp = cand.playerB
            cand.playerB = m.playerB
            m.playerB = tmp
            swapped = true
            break
          }
          // try swap m.playerB with cand.playerA
          if (cand.playerA && cand.playerA.clubId !== m.playerA.clubId) {
            const tmp = cand.playerA
            cand.playerA = m.playerB as PlayerForFixture
            m.playerB = tmp
            swapped = true
            break
          }
        }
        // if couldn't swap, leave as is (best-effort)
      }
    }
  }

  return { matches, byes }
}
