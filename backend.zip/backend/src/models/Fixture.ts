export class FixtureModel {
  static generate(players: any[]){
    // simple greedy knockout placeholder
    const list = [...players]
    const fixtures = []
    while(list.length>1){
      const a = list.shift()
      const b = list.shift()
      fixtures.push({ a, b })
    }
    if(list.length===1) fixtures.push({ a: list.shift(), b: null })
    return fixtures
  }
}
