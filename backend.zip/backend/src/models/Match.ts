export class MatchModel {
  static create(){
    return { id: 'm1', code: 'abc123', expiresAt: Date.now() + 1000*60*30 }
  }
}
