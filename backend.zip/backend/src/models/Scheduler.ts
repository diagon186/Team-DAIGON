import { v4 as uuidv4 } from 'uuid'

export type FixtureMatch = { id: string; playerAId: string; playerBId?: string | null; round: number }
export type ScheduledMatch = { id: string; matchId: string; court: string; start: number; end: number }

// Simple scheduler: assign matches to courts in round-robin order, respecting matchDuration and buffer
export function scheduleMatches(matches: FixtureMatch[], options: { courts: string[]; matchDurationMin: number; bufferMin: number; startAt?: number }) : ScheduledMatch[] {
  const courts = options.courts
  const duration = (options.matchDurationMin || 10) * 60 * 1000
  const buffer = (options.bufferMin || 10) * 60 * 1000
  const startAt = options.startAt ?? Date.now()

  const scheduled: ScheduledMatch[] = []

  // keep track of next available time per court
  const nextAvailableCourt: Record<string, number> = {}
  for (const c of courts) nextAvailableCourt[c] = startAt

  // keep track of next available time per player to avoid overlap
  const nextAvailablePlayer: Record<string, number> = {}

  // filter out bye matches (no opponent)
  const actualMatches = matches.filter(m => m.playerBId)

  // greedy: for each match, pick the court that yields the earliest feasible start considering both court and player availability
  for (const m of actualMatches) {
    const playerA = m.playerAId
    const playerB = m.playerBId as string

    let bestCourt: string | null = null
    let bestStart = Number.POSITIVE_INFINITY

    for (const court of courts) {
      const courtAvail = nextAvailableCourt[court]
      const pAAvail = nextAvailablePlayer[playerA] ?? startAt
      const pBAvail = nextAvailablePlayer[playerB] ?? startAt
      const earliest = Math.max(courtAvail, pAAvail, pBAvail)
      if (earliest < bestStart) {
        bestStart = earliest
        bestCourt = court
      }
    }

    const s = bestStart
    const e = s + duration
    const sm: ScheduledMatch = { id: uuidv4(), matchId: m.id, court: bestCourt as string, start: s, end: e }
    scheduled.push(sm)

    // update next available for that court and both players
    nextAvailableCourt[bestCourt as string] = e + buffer
    nextAvailablePlayer[playerA] = e + buffer
    nextAvailablePlayer[playerB] = e + buffer
  }

  return scheduled
}
