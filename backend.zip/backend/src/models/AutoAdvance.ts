import { v4 as uuidv4 } from 'uuid'
import db from '../db'

// When a match completes, check whether the whole round is complete.
// If yes, collect winners in match order and generate next-round matches.
export function advanceIfRoundComplete(completedMatchId: string) {
  const fixtures = db.getFixtures()
  const completed = fixtures.find((f:any)=>f.id===completedMatchId)
  if (!completed) return null
  const round = completed.round

  const roundMatches = fixtures.filter((f:any)=>f.round === round && f.status !== 'withdrawn')
  // if any match in the round is not completed, bail
  const allDone = roundMatches.every((m:any)=>m.status === 'completed' && m.result && m.result.winnerId)
  if (!allDone) return null

  // collect winners in the order of roundMatches array
  const winners = roundMatches.map((m:any)=>m.result.winnerId)

  // pair winners to create next-round matches
  const nextRound = round + 1
  const nextMatches: { id: string; playerAId: string; playerBId?: string | null; round: number }[] = []
  for (let i = 0; i < winners.length; i += 2) {
    const a = winners[i]
    const b = winners[i+1] ?? null
    nextMatches.push({ id: uuidv4(), playerAId: a, playerBId: b, round: nextRound })
  }

  if (nextMatches.length === 0) return null
  const stored = db.addRawFixtures(nextMatches)

  // emit event via socket if possible
  try {
    const { getIo } = require('../socket')
    const io = getIo()
    io.emit('fixtures:advanced', { round: nextRound, matches: stored })
  } catch (e) {}

  return stored
}

export default { advanceIfRoundComplete }
