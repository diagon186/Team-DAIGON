export class PlayerModel {
  static validate(input: any){
    if (!input.name) throw new Error('invalid')
    return true
  }
}
