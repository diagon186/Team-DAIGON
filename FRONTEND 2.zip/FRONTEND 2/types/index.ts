export interface Player {
  id: string
  name: string
  clubId?: string
  seed?: number
}

export interface Match {
  id: string
  playerA: string
  playerB: string
  scheduledAt?: string
}
