// Placeholder firebase client config and listener helpers
export function initFirebase(){
  // initialize firebase client SDK here
}

export function onLeaderboardUpdate(cb: (data:any)=>void){
  // call cb on snapshot updates
}
