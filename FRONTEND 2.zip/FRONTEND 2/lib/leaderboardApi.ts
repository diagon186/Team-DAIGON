const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'

export async function fetchLeaderboard(){
  const res = await fetch(`${API_BASE}/leaderboard`)
  return res.json()
}
