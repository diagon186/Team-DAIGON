const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'

export async function fetchPlayers(){
  const res = await fetch(`${API_BASE}/players`)
  return res.json()
}

export async function postPlayer(payload: any){
  const res = await fetch(`${API_BASE}/players`, { method: 'POST', body: JSON.stringify(payload), headers: { 'Content-Type':'application/json' } })
  return res
}

export async function fetchClubs(){
  const res = await fetch(`${API_BASE}/clubs`)
  return res.json()
}

export async function postFixtures(payload: any){
  const res = await fetch(`${API_BASE}/fixtures`, { method: 'POST', body: JSON.stringify(payload), headers: { 'Content-Type':'application/json' } })
  return res.json()
}
