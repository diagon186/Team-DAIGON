const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'

export async function fetchSchedules(){
  const res = await fetch(`${API_BASE}/schedule`)
  return res.json()
}

export async function requestMatchCode(matchId: string){
  const res = await fetch(`${API_BASE}/matches`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ matchId, ttlMin: 30 }) })
  return res.json()
}

export async function submitMatchResult(code: string, payload: any){
  const res = await fetch(`${API_BASE}/matches/${code}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
  return res.json()
}

export async function revokeMatchCode(code: string){
  const res = await fetch(`${API_BASE}/matches/${code}`, { method: 'DELETE' })
  return res.json()
}
